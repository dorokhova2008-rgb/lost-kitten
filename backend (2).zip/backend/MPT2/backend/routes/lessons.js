const express = require("express");
const router = express.Router();
const pool = require("../db");

router.get("/", async (req,res)=>{
    try{
        const result = await pool.query(`
            SELECT
                products.id_product,
                products.product_name,
                products.product_description,
                products.price,
                categories.category_name
            FROM products
            JOIN categories
            ON products.category_id = categories.id_category
            ORDER BY products.id_product;
            `);
            res.json(result.rows);
    }
    catch(error){
        console.error(error);
        res.status(500).json({
            message:"Get items error"
        });
    }
});

router.get("/:id", async(req,res)=>{
    try{
        const id = req.params.id;
        const result = await pool.query(
            `SELECT
                products.id_product,
                products.product_name,
                products.product_description,
                products.price,
                categories.category_name
            FROM products
            JOIN categories
            ON products.category_id = categories.id_category
            WHERE products.id_product = $1;`,
            [id]
        );
        if(result.rows.length ===0){
            return res.status(404).json({
                message:"Item is not found"
            });
        }
        res.json(result.rows[0]);
    }
    catch(error){
        console.error(error);
        res.status(500).json({
            message:"Get item error"
        });
    }
});

router.post("/", async (req,res)=>{
    try{
        const {product_name,product_description,price,category_id} = req.body;
        if(!product_name || !price || !category_id){
            return res.status(400).json({
                message:"Fill product name,product description,price,category"
            });
        }
        const result = await pool.query(
            `INSERT INTO products
            (product_name, product_description, price, category_id)
            VALUES ($1, $2, $3, $4)
            RETURNING *`,
            [product_name, product_description, price, category_id]
        );
        res.json({
            message:"Item added",
            product: result.rows[0]
        });
    }
    catch(error){
        console.error(error);
        res.status(500).json({
            message:"Add item error"
        });
    }
});

router.delete("/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const result = await pool.query(
            "DELETE FROM products WHERE id_product = $1 RETURNING *",
            [id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({
                message: "Товар не найден"
            });
        }
        res.json({
            message: "Товар удалён"
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Ошибка при удалении товара"
        });
    }
});
module.exports = router;

