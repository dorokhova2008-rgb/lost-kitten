const express = require("express");
const router = express.Router();
const pool = require("../db");

router.post("/register", async(req,res)=>{
    try{
        const{username, password, email}=req.body;
        if(!username || !password || !email){
            return res.status(400).json({
                message:"Fill the fields"
            });
        }
        let roleResult = await pool.query(
            "SELECT id_role FROM roles WHERE role_name= $1",
            ["user"]
        );
        let roleId;
        if(roleResult.rows.length === 0){
            const newRole = await pool.query(
                "INSERT INTO roles (role_name) VALUES ($1) RETURNING id_role",
                ["user"]
            );
            roleId = newRole.rows[0].id_role;
        }
        else{
            roleId = roleResult.rows[0].id_role;
        }
        const result = await pool.query(
            `INSERT INTO users (username, password_hash, email, role_id)
            VALUES ($1, $2, $3, $4)
            RETURNING id_user, username, email, role_id`,
            [username, password, email, roleId]
        );
        res.json({
            message:"User is registered",
            user: result.rows[0]
        });
    }
    catch(error){
        console.error(error);
        res.status(500).json({
            message: "Registration error"
        });
    }
});

router.post("/login", async(req,res)=>{
    try{
        const{username,password}=req.body;
        if(!username || !password){
            return res.status(400).json({
                message: "Enter username n password"
            });
        }
        const result = await pool.query(
            `SELECT
                users.id_user,
                users.username,
                users.email,
                roles.role_name
            FROM users
            JOIN roles ON users.role_id = roles.id_role
            WHERE users.username = $1 AND users.password_hash = $2`,
            [username, password]
        );
        if (result.rows.length ===0){
            return res.status(401).json({
                message: "Invalid password or username"
            });
        }
        res.json({
            message:"Log in completed",
            user:result.rows[0]
        });
    }
    catch(error){
        console.error(error);
        res.status(500).json({
            message:"Log in error"
        });
    }
});
module.exports = router;