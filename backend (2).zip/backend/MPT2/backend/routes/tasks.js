const express = require("express");
const router = express.Router();
const pool = require("../db");

router.get("/", async function(req, res) {
    try {
        const result = await pool.query("SELECT * FROM tasks ORDER BY id_task DESC");
        res.json(result.rows);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Ошибка получения товаров доски" });
    }
});
router.post("/", async function(req, res) {
    try {
        const title = req.body.title;
        const description = req.body.description;
        const status = req.body.status;

        const result = await pool.query(
            "INSERT INTO tasks (task_title, task_description, task_status) VALUES ($1, $2, $3) RETURNING *",
            [title, description, status]
        );
        res.json(result.rows[0]);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Ошибка добавления товара на доску" });
    }
});
router.put("/:id", async function(req, res) {
    try {
        const id = req.params.id;
        const title = req.body.title;
        const description = req.body.description;
        const status = req.body.status;
        const result = await pool.query(
            "UPDATE tasks SET task_title = $1, task_description = $2, task_status = $3 WHERE id_task = $4 RETURNING *",
            [title, description, status, id]
        );
        res.json(result.rows[0]);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Ошибка изменения товара" });
    }
});
router.patch("/:id/status", async function(req, res) {
    try {
        const id = req.params.id;
        const status = req.body.status;
        const result = await pool.query(
            "UPDATE tasks SET task_status = $1 WHERE id_task = $2 RETURNING *",
            [status, id]
        );
        res.json(result.rows[0]);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Ошибка изменения статуса" });
    }
});
router.delete("/:id", async function(req, res) {
    try {
        const id = req.params.id;
        await pool.query("DELETE FROM tasks WHERE id_task = $1", [id]);
        res.json({ message: "Товар удалён с доски" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Ошибка удаления товара" });
    }
});
module.exports = router;