const productsBlock = document.getElementById("products");
const registerForm = document.getElementById("registerForm");
const registerMessage = document.getElementById("registerMessage");
const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");

const taskTitle = document.getElementById("taskTitle");
const taskDescription = document.getElementById("taskDescription");
const taskStatus = document.getElementById("taskStatus");
const addTaskBtn = document.getElementById("addTaskBtn");
const searchInput = document.getElementById("searchInput");
const filterStatus = document.getElementById("filterStatus");
const sortTasks = document.getElementById("sortTasks");
const taskCounter = document.getElementById("taskCounter");
const taskMessage = document.getElementById("taskMessage");
const columns = document.querySelectorAll(".column");
let tasks = [];

async function loadProducts() {
    try {
        const response = await fetch("/api/products");
        const products = await response.json();
        productsBlock.innerHTML = "";
        if (products.length === 0) {
            productsBlock.innerHTML = "<p>Товаров пока нет.</p>";
            return;
        }
        products.forEach(product => {
            const card = document.createElement("div");
            card.className = "card";
            card.innerHTML = `
                <h3>${product.product_name}</h3>
                <p>${product.product_description}</p>
                <p class="price">${product.price} ₽</p>
                <p class="category">Категория: ${product.category_name}</p>
                <button>Заказать</button>
            `;
            productsBlock.appendChild(card);
        });
    } catch (error) {
        console.log(error);
        productsBlock.innerHTML = "<p>Ошибка загрузки товаров.</p>";
    }
}

registerForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    const username = document.getElementById("regUsername").value;
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;

    try {
        const response = await fetch("/api/auth/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                username: username,
                email: email,
                password: password
            })
        });
        const data = await response.json();
        registerMessage.textContent = data.message;
        if (response.ok) {
            registerForm.reset();
        }
    } catch (error) {
        console.log(error);
        registerMessage.textContent = "Ошибка регистрации";
    }
});
loginForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    const username = document.getElementById("loginUsername").value;
    const password = document.getElementById("loginPassword").value;

    try {
        const response = await fetch("/api/auth/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });
        const data = await response.json();
        loginMessage.textContent = data.message;
        if (response.ok && data.user) {
            loginMessage.textContent = "Вы вошли как: " + data.user.username;
            loginForm.reset();
        }
    } catch (error) {
        console.log(error);
        loginMessage.textContent = "Ошибка входа";
    }
});
async function loadTasks() {
    try {
        const response = await fetch("/api/tasks");
        tasks = await response.json();

        localStorage.setItem("tasks", JSON.stringify(tasks));

        renderTasks();
    } catch (error) {
        console.log(error);

        const savedTasks = localStorage.getItem("tasks");

        if (savedTasks) {
            tasks = JSON.parse(savedTasks);
        }

        renderTasks();
    }
}
function renderTasks() {
    document.getElementById("plan").innerHTML = "";
    document.getElementById("progress").innerHTML = "";
    document.getElementById("review").innerHTML = "";
    document.getElementById("done").innerHTML = "";

    let filteredTasks = [...tasks];
    const searchText = searchInput.value.toLowerCase();
    const filterValue = filterStatus.value;
    const sortValue = sortTasks.value;
    if (searchText !== "") {
        filteredTasks = filteredTasks.filter(function(task) {
            return task.task_title.toLowerCase().includes(searchText) ||
                (task.task_description || "").toLowerCase().includes(searchText);
        });
    }
    if (filterValue !== "all") {
        filteredTasks = filteredTasks.filter(function(task) {
            return task.task_status === filterValue;
        });
    }
    if (sortValue === "new") {
        filteredTasks.sort(function(a, b) {
            return b.id_task - a.id_task;
        });
    }
    if (sortValue === "old") {
        filteredTasks.sort(function(a, b) {
            return a.id_task - b.id_task;
        });
    }
    if (sortValue === "az") {
        filteredTasks.sort(function(a, b) {
            return a.task_title.localeCompare(b.task_title);
        });
    }
    filteredTasks.forEach(function(task) {
        const card = document.createElement("div");
        card.className = "task-card";
        card.draggable = true;
        card.dataset.id = task.id_task;
        card.innerHTML = `
            <h4>${task.task_title}</h4>
            <p>${task.task_description || ""}</p>

            <div class="task-buttons">
                <button onclick="editTask(${task.id_task})">Редактировать</button>
                <button onclick="deleteTask(${task.id_task})">Удалить</button>
            </div>
        `;

        card.addEventListener("dragstart", dragStart);
    let status = task.task_status;

if (status === "Хочу купить") {
    status = "plan";
}

if (status === "Слежу за скидкой") {
    status = "progress";
}

if (status === "В корзине") {
    status = "review";
}

if (status === "Куплено") {
    status = "done";
}

const column = document.getElementById(status);

if (column) {
    column.appendChild(card);
}
    });
    taskCounter.textContent = tasks.length;
}

addTaskBtn.addEventListener("click", async function() {
    const title = taskTitle.value.trim();
    const description = taskDescription.value.trim();
    const status = taskStatus.value;
    if (title === "") {
        showMessage("Введите название товара");
        return;
    }
    try {
        const response = await fetch("/api/tasks", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                title: title,
                description: description,
                status: status
            })
        });
        const newTask = await response.json();
        tasks.unshift(newTask);
        localStorage.setItem("tasks", JSON.stringify(tasks));
        taskTitle.value = "";
        taskDescription.value = "";
        taskStatus.value = "plan";
        renderTasks();
        showMessage("Товар добавлен на доску");
    } catch (error) {
        console.log(error);
        showMessage("Ошибка добавления товара");
    }
});
async function editTask(id) {
    const task = tasks.find(function(item) {
        return item.id_task === id;
    });
    if (!task) {
        return;
    }
    const newTitle = prompt("Новое название товара:", task.task_title);
    const newDescription = prompt("Новый комментарий:", task.task_description);
    if (newTitle === null || newTitle.trim() === "") {
        return;
    }
    try {
        const response = await fetch(`/api/tasks/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                title: newTitle,
                description: newDescription,
                status: task.task_status
            })
        });
        const updatedTask = await response.json();
        tasks = tasks.map(function(item) {
            if (item.id_task === id) {
                return updatedTask;
            }
            return item;
        });
        localStorage.setItem("tasks", JSON.stringify(tasks));
        renderTasks();
        showMessage("Товар изменён");
    } catch (error) {
        console.log(error);
        showMessage("Ошибка изменения товара");
    }
}
async function deleteTask(id) {
    const confirmDelete = confirm("Удалить товар с доски?");
    if (!confirmDelete) {
        return;
    }
    try {
        await fetch(`/api/tasks/${id}`, {
            method: "DELETE"
        });
        tasks = tasks.filter(function(task) {
            return task.id_task !== id;
        });
        localStorage.setItem("tasks", JSON.stringify(tasks));
        renderTasks();
        showMessage("Товар удалён с доски");
    } catch (error) {
        console.log(error);
        showMessage("Ошибка удаления товара");
    }
}
function dragStart(event) {
    event.dataTransfer.setData("text/plain", event.target.dataset.id);
    event.target.classList.add("dragging");
}
function dragEnd(event) {
    event.target.classList.remove("dragging");
}
columns.forEach(function(column) {
    column.addEventListener("dragover", function(event) {
        event.preventDefault();
        column.classList.add("drag-over");
    });
    column.addEventListener("dragleave", function() {
        column.classList.remove("drag-over");
    });
    column.addEventListener("drop", async function(event) {
        event.preventDefault();
        column.classList.remove("drag-over");
        const taskId = Number(event.dataTransfer.getData("text/plain"));
        const newStatus = column.dataset.status;
        await changeTaskStatus(taskId, newStatus);
    });
});
async function changeTaskStatus(id, status) {
    try {
        const response = await fetch(`/api/tasks/${id}/status`, {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                status: status
            })
        });
        const updatedTask = await response.json();
        tasks = tasks.map(function(task) {
            if (task.id_task === id) {
                return updatedTask;
            }
            return task;
        });
        localStorage.setItem("tasks", JSON.stringify(tasks));
        renderTasks();
        showMessage("Статус товара изменён");
    } catch (error) {
        console.log(error);
        showMessage("Ошибка переноса товара");
    }
}
function showMessage(text) {
    taskMessage.textContent = text;

    setTimeout(function() {
        taskMessage.textContent = "";
    }, 2500);
}
searchInput.addEventListener("input", renderTasks);
filterStatus.addEventListener("change", renderTasks);
sortTasks.addEventListener("change", renderTasks);
loadProducts();
loadTasks();